#!/bin/bash

COMMAND_FILE="command.txt"

while [ -s "$COMMAND_FILE" ]; do
  CMD=$(head -n 1 "$COMMAND_FILE")
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] Executing: $CMD"
  eval "$CMD"
  sed -i '1d' "$COMMAND_FILE"
done

echo "All commands executed."
